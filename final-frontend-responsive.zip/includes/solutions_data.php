<?php
/**
 * MH Trade Capital Solutions — Central Data Repository for 5 Core Capabilities & Solutions
 */

function getSolutionsData() {
    return [
        'trade-finance' => [
            'id' => 'trade-finance',
            'num' => '01',
            'title' => 'Trade Finance & Banking Instruments',
            'heroHeadline' => 'DON\'T JUST ASK FOR A FINANCIAL INSTRUMENT.<br><span style="color: var(--gold-primary);">UNDERSTAND THE TRANSACTION FIRST.</span>',
            'badge' => 'LC • DLC • UPAS LC • Usance LC • SBLC • BG • PG • APG • Tender Guarantee • BCL • POF • RWA • SWIFT-Related Instruments',
            'tags' => ['LC / DLC', 'SBLC / BG', 'PG / APG', 'BCL / POF / RWA'],
            'image' => 'images/verticals/trade_finance.webp',
            'shortDesc' => 'Trade finance structuring and applicable banking instruments for eligible commercial ...',
            'overview' => 'Trade finance structuring and applicable banking instruments for eligible commercial transactions, subject to transaction assessment, compliance requirements and the final approval of the relevant bank or financial institution.',
            'items' => [
                [
                    'num' => '01',
                    'title' => 'Letter of Credit (LC)',
                    'subtitle' => 'A Bank-Supported Payment Mechanism for International Trade',
                    'desc' => 'A Letter of Credit (LC) is a bank-issued undertaking used in international trade to provide a structured payment mechanism between a buyer and seller. Under an LC, the issuing bank agrees to make payment to the beneficiary when the required documents are presented and comply with the terms and conditions of the credit.',
                    'details' => 'An LC is commonly used where the buyer and seller want payment to be linked to specified documentary requirements, such as commercial invoices, transport documents, certificates of origin and inspection documents. The payment terms, required documents, expiry, shipment conditions and other requirements are defined in the LC. Payment is made according to the applicable terms when a compliant presentation is made.',
                    'summary' => 'In simple terms: an LC provides a bank-based payment structure in which payment is made against documents that meet the conditions of the credit.'
                ],
                [
                    'num' => '02',
                    'title' => 'Documentary Letter of Credit (DLC)',
                    'subtitle' => 'A Documentary Payment Structure for International Trade',
                    'desc' => 'A Documentary Letter of Credit (DLC) is a type of Letter of Credit under which payment is linked to the presentation of specified documents that comply with the terms and conditions of the credit. It is commonly used to structure payment between an importer and exporter in an international trade transaction.',
                    'details' => 'A DLC may require documents such as commercial invoices, bills of lading, certificates of origin, packing lists, insurance documents or inspection certificates, depending on the transaction. The issuing bank undertakes to honour the credit when a complying presentation is made in accordance with the documentary requirements and applicable terms of the credit.',
                    'summary' => 'In simple terms: a DLC connects payment to the proper presentation of the documents required under the credit.'
                ],
                [
                    'num' => '03',
                    'title' => 'UPAS LC — Usance Payable At Sight',
                    'subtitle' => 'A Deferred-Payment Trade Finance Structure with Sight Payment to the Seller',
                    'desc' => 'A UPAS Letter of Credit is a trade finance structure that allows the seller to receive payment at sight while the buyer obtains a deferred payment period. It is commonly used in international trade where the seller requires prompt payment but the buyer needs additional time to settle the transaction.',
                    'details' => 'Under a UPAS LC, the relevant payment structure allows the beneficiary to receive payment at sight, while the importer or applicant settles the financing obligation at a later agreed maturity date. The credit specifies the applicable tenor, documentary requirements, payment terms and other conditions. The financing and payment arrangements are subject to the structure agreed among the relevant parties and banks.',
                    'summary' => 'In simple terms: a UPAS LC can allow the seller to be paid promptly while giving the buyer an agreed period before the payment obligation becomes due.'
                ],
                [
                    'num' => '04',
                    'title' => 'Usance Letter of Credit',
                    'subtitle' => 'A Deferred-Payment Mechanism for International Trade',
                    'desc' => 'A Usance Letter of Credit is a Letter of Credit under which payment is made at a specified future date or after an agreed period rather than immediately upon presentation of complying documents.',
                    'details' => 'It is commonly used when a buyer and seller agree on deferred payment terms, allowing the buyer a defined period to make payment after shipment or presentation of the required documents. The LC specifies the usance period, documentary requirements, maturity date and other applicable conditions. Once the required documents are presented and comply with the credit, the payment obligation becomes payable according to the agreed tenor.',
                    'summary' => 'In simple terms: a Usance LC provides a documentary payment structure where payment is scheduled for a future agreed date rather than being made immediately.'
                ],
                [
                    'num' => '05',
                    'title' => 'Standby Letter of Credit (SBLC)',
                    'subtitle' => 'A Bank Commitment Supporting Performance or Payment Obligations',
                    'desc' => 'A Standby Letter of Credit (SBLC) is a bank-issued undertaking designed to provide financial assurance if the applicant fails to meet a specified payment or contractual obligation.',
                    'details' => 'An SBLC is commonly used as a form of security or credit support in commercial, financial and contractual arrangements. Unlike a conventional commercial LC, it is generally intended to be drawn upon only if the underlying obligation is not fulfilled, subject to the terms of the SBLC. The SBLC defines the amount, expiry, conditions for presentation and documents or statements required for a valid demand. If the specified conditions for drawing are satisfied, the bank acts according to the terms of the undertaking.',
                    'summary' => 'In simple terms: an SBLC provides a bank-backed assurance that can be called upon if the applicant does not fulfil the specified obligation.'
                ],
                [
                    'num' => '06',
                    'title' => 'Bank Guarantee (BG)',
                    'subtitle' => 'A Bank-Backed Guarantee of Contractual or Financial Obligations',
                    'desc' => 'A Bank Guarantee (BG) is a bank-issued undertaking in which the bank agrees to pay the beneficiary if the applicant fails to fulfil a specified obligation, subject to the terms of the guarantee.',
                    'details' => 'BGs are commonly used in commercial contracts, construction, procurement, supply arrangements and other transactions where one party requires financial assurance from the other party. The guarantee normally specifies the guaranteed amount, beneficiary, applicant, expiry date, underlying obligation and conditions under which a claim may be made. The bank\'s liability is determined by the wording and terms of the guarantee.',
                    'summary' => 'In simple terms: a BG provides the beneficiary with bank-backed security against specified non-performance or non-payment by the applicant.'
                ],
                [
                    'num' => '07',
                    'title' => 'Performance Guarantee (PG)',
                    'subtitle' => 'A Bank Guarantee Supporting Contractual Performance',
                    'desc' => 'A Performance Guarantee (PG) is a type of bank guarantee used to provide assurance that a contractual obligation or performance requirement will be fulfilled.',
                    'details' => 'It is commonly used in construction, infrastructure, procurement, supply and service contracts where the beneficiary requires protection against failure to perform according to the agreed contractual terms. The guarantee specifies the amount, validity period and conditions under which the beneficiary may make a claim. If the applicant fails to meet the relevant contractual obligation and the claim satisfies the guarantee\'s requirements, the issuing bank may be required to honour the claim according to its terms.',
                    'summary' => 'In simple terms: a PG provides bank-backed security to support the applicant\'s contractual performance.'
                ],
                [
                    'num' => '08',
                    'title' => 'Advance Payment Guarantee (APG)',
                    'subtitle' => 'A Bank Guarantee Protecting an Advance Payment',
                    'desc' => 'An Advance Payment Guarantee (APG) is a bank guarantee designed to protect a buyer or contracting party when an advance payment is made to a supplier or contractor.',
                    'details' => 'It is commonly used in contracts where the buyer agrees to make an upfront payment before the supplier or contractor has fully performed its contractual obligations. The APG generally covers the agreed advance amount and specifies its validity and claim conditions. If the supplier or contractor fails to fulfil the relevant contractual obligations, the beneficiary may make a claim in accordance with the terms of the guarantee.',
                    'summary' => 'In simple terms: an APG provides protection to the party making an advance payment by securing that payment through a bank guarantee.'
                ],
                [
                    'num' => '09',
                    'title' => 'Bank Comfort Letter (BCL)',
                    'subtitle' => 'A Bank Communication Indicating Financial or Banking Support',
                    'desc' => 'A Bank Comfort Letter (BCL) is a banking communication issued at the request of a customer to provide a stated indication regarding the customer\'s banking relationship, financial position or ability to support a proposed transaction, subject to the wording of the specific letter.',
                    'details' => 'BCLs may be used in commercial or financial discussions where a counterparty requires some form of preliminary banking confirmation before proceeding with a transaction or arrangement. The content and legal effect of a BCL depend entirely on its wording and issuing bank. A BCL does not, by itself, necessarily constitute a payment undertaking, guarantee or commitment to provide funds.',
                    'summary' => 'In simple terms: a BCL is generally a bank communication intended to provide a specified level of financial or banking comfort, rather than a direct payment guarantee.'
                ],
                [
                    'num' => '10',
                    'title' => 'Proof of Funds (POF)',
                    'subtitle' => 'Evidence of Available Financial Capacity',
                    'desc' => 'Proof of Funds (POF) is documentation or a financial confirmation used to demonstrate that a person or entity has access to sufficient funds or financial resources for a specified purpose.',
                    'details' => 'POF may be requested in transactions such as property purchases, investments, acquisitions, commodity transactions or other commercial arrangements where a counterparty needs evidence of financial capacity. The form of POF may vary depending on the transaction and the institution providing the confirmation. The document may indicate an available balance, account status or other relevant financial information, subject to applicable privacy, banking and verification requirements.',
                    'summary' => 'In simple terms: POF is evidence intended to demonstrate that the required financial resources are available or accessible for a particular transaction.'
                ],
                [
                    'num' => '11',
                    'title' => 'Ready, Willing & Able (RWA)',
                    'subtitle' => 'A Financial or Banking Confirmation of Transaction Readiness',
                    'desc' => 'A Ready, Willing & Able (RWA) communication is generally used to indicate that a party has expressed its readiness, willingness and ability to proceed with a proposed financial or commercial transaction, subject to the applicable terms and conditions.',
                    'details' => 'An RWA may be used during preliminary transaction discussions where counterparties require an indication that the relevant party is prepared and positioned to proceed with the proposed arrangement. The exact meaning, authority and legal effect of an RWA depend on its issuer, wording, purpose and the transaction structure. An RWA should not automatically be interpreted as a guarantee, proof of funds or an unconditional commitment to provide financing.',
                    'summary' => 'In simple terms: an RWA is a transaction-related confirmation indicating readiness and ability to proceed, subject to the applicable conditions and requirements.'
                ]
            ]
        ],

        'uae-banking' => [
            'id' => 'uae-banking',
            'num' => '02',
            'title' => 'UAE Business & Corporate Banking',
            'heroHeadline' => 'STREAMLINED UAE COMPANY FORMATION & <br><span style="color: var(--gold-primary);">CORPORATE BANKING SOLUTIONS</span>',
            'badge' => 'Company Formation • Business Licensing • Corporate Banking • Business Accounts • Residency & Visa Support • Family Residency',
            'tags' => ['Company Formation', 'Corporate Banking', 'Licensing', 'Residency & Visa'],
            'image' => 'images/verticals/uae_banking.jpg',
            'shortDesc' => 'Supporting entrepreneurs and businesses with UAE company formation, licensing, corporate banking ...',
            'overview' => 'Supporting entrepreneurs and businesses with UAE company formation, licensing, corporate banking, business accounts, residency and visa-related requirements, including eligible family residency arrangements. We assist with documentation, application preparation and coordination with relevant authorities, free zones and banking channels, subject to applicable UAE regulations, eligibility requirements and final approval.',
            'processText' => 'We first understand your business activity, ownership structure, business requirements and banking needs. Based on your profile, we coordinate the relevant company formation, licensing, documentation, corporate banking, residency and visa-related processes, including support for eligible family residency arrangements. Our role is to assist with the process and coordinate with the relevant government authorities, free zones, service providers and banking channels, subject to applicable UAE laws, regulations, eligibility requirements and final approval by the relevant authority or institution.',
            'items' => [
                [
                    'num' => '01',
                    'title' => 'Company Formation & Business Licensing',
                    'subtitle' => 'Free Zone & Mainland Corporate Setup',
                    'desc' => 'Assistance with selecting appropriate business activities, jurisdiction (Free Zone or Mainland), and company structuring for long-term commercial growth.',
                    'details' => 'Full coordination of trade name reservation, memorandum of association (MOA), initial approvals, and issuance of trade licenses.',
                    'summary' => 'Streamlined setup tailored to your international trading and commercial activities.'
                ],
                [
                    'num' => '02',
                    'title' => 'Corporate Banking & Multi-Currency Business Accounts',
                    'subtitle' => 'Bank Account Advisory & Opening Coordination',
                    'desc' => 'Guidance through banking compliance requirements, business profile preparation, background documentation, and interview preparation with tier-1 UAE banks.',
                    'details' => 'Support for multi-currency trade accounts (USD, EUR, AED, GBP) with online banking access and transaction support.',
                    'summary' => 'Direct alignment with UAE corporate banking institutions.'
                ],
                [
                    'num' => '03',
                    'title' => 'Residency & Visa Support',
                    'subtitle' => 'Investor, Partner & Family Residency Visas',
                    'desc' => 'End-to-end management of investor visas, employment visas, Emirates ID processing, medical fitness testing, and family residency sponsorship.',
                    'details' => 'Ensuring complete compliance with UAE Federal Authority for Identity and Citizenship (ICP) guidelines.',
                    'summary' => 'Comprehensive residency visa processing for business owners and family members.'
                ]
            ]
        ],

        'project-finance' => [
            'id' => 'project-finance',
            'num' => '03',
            'title' => 'Project Finance',
            'heroHeadline' => 'LONG-TERM, LIMITED-RECOURSE <br><span style="color: var(--gold-primary);">PROJECT FINANCING SOLUTIONS</span>',
            'badge' => 'INFRASTRUCTURE • GREEN PROJECTS • AGRICULTURE • ENERGY PROJECTS',
            'tags' => ['Infrastructure', 'Green Projects', 'Agriculture', 'Energy Projects'],
            'image' => 'images/verticals/project_finance.jpg',
            'shortDesc' => 'Long-term, limited-recourse project financing for eligible infrastructure, green, agriculture and energy projects ...',
            'overview' => 'Long-term, limited-recourse project financing for eligible infrastructure, green, agriculture and energy-related projects, assessed on a case-by-case basis and subject to applicable financing criteria, due diligence and final approval by the relevant financing institution.',
            'items' => [
                [
                    'num' => '01',
                    'title' => 'Infrastructure Projects',
                    'subtitle' => 'Transport, Utilities, Logistics & Public Facilities',
                    'desc' => 'Development and capital structuring of essential infrastructure such as transport networks, utilities, logistics parks, ports, and public facilities.',
                    'details' => 'Evaluating project cash flows, EPC contracts, and off-take agreements to align with debt and equity syndication requirements.',
                    'summary' => 'Structuring long-term capital for core economic infrastructure.'
                ],
                [
                    'num' => '02',
                    'title' => 'Green Projects',
                    'subtitle' => 'Sustainable Development & Environmental Technology',
                    'desc' => 'Projects focused on sustainable development, environmental efficiency, clean technologies, carbon reduction, and resource conservation.',
                    'details' => 'Assessing green taxonomy alignment, ESG compliance, and long-term environmental performance metrics for institutional funders.',
                    'summary' => 'Capital support for environmental and sustainable developments.'
                ],
                [
                    'num' => '03',
                    'title' => 'Agriculture Projects',
                    'subtitle' => 'Farming, Food Security & Processing Infrastructure',
                    'desc' => 'Agricultural developments covering commercial farming, food production, irrigation systems, processing facilities, and cold-chain logistics infrastructure.',
                    'details' => 'Structuring funding models aligned with seasonal yields, supply chain off-takers, and food security initiatives.',
                    'summary' => 'Financing agricultural value chains and food production facilities.'
                ],
                [
                    'num' => '04',
                    'title' => 'Energy Projects',
                    'subtitle' => 'Power Generation, Renewable Energy & Facilities',
                    'desc' => 'Projects involving power generation, energy infrastructure, solar, wind, hydro renewable energy installations, and related grid facilities.',
                    'details' => 'Structuring limited-recourse debt financing based on Power Purchase Agreements (PPAs) and concession arrangements.',
                    'summary' => 'Capital structuring for conventional and renewable power generation.'
                ]
            ]
        ],

        'commodity-trade' => [
            'id' => 'commodity-trade',
            'num' => '04',
            'title' => 'Commodity Trade Solutions',
            'heroHeadline' => 'QUALIFIED COMMODITY SOURCING & <br><span style="color: var(--gold-primary);">INTERNATIONAL TRADE FACILITATION</span>',
            'badge' => 'Sugar • Rice • Spices • Crude Oil • Cooking Oil • Gold • Bitcoin & Selected Digital Assets',
            'tags' => ['Energy & Agri', 'Precious Metals', 'Soft Commodities', 'Digital Assets'],
            'image' => 'images/verticals/commodity.webp',
            'shortDesc' => 'Support for qualified commodity transactions, including sourcing, trade structuring, transaction coordination ...',
            'overview' => 'Support for qualified commodity transactions, including sourcing, trade structuring, transaction coordination and related financial requirements across international markets.',
            'items' => [
                [
                    'num' => '01',
                    'title' => 'Sugar',
                    'subtitle' => 'Refined & Raw Commercial Sugar Sourcing',
                    'desc' => 'Refined sugar supplied to commercial specifications (ICUMSA 45 / 600-1200), suitable for food manufacturing and industrial applications.',
                    'details' => 'Coordinating verified allocation holders, shipping terms (FOB/CIF), and banking instrument compliance.',
                    'summary' => 'Quality commercial sugar allocations for global industrial buyers.'
                ],
                [
                    'num' => '02',
                    'title' => 'Rice',
                    'subtitle' => 'Basmati & Non-Basmati Commercial Grain',
                    'desc' => 'Quality rice sourced to defined grades and specifications (Basmati, Long Grain White Rice, Parboiled) for international food markets.',
                    'details' => 'Sourcing from origin mills with inspection certification (SGS) and export documentation.',
                    'summary' => 'Graded agricultural rice supply for international trade.'
                ],
                [
                    'num' => '03',
                    'title' => 'Spices',
                    'subtitle' => 'High-Grade Bulk Commercial Spices',
                    'desc' => 'Selected spices with defined origin, quality standards, moisture parameters, and specifications for global trade.',
                    'details' => 'Facilitating commercial contracts and logistics coordination for food processing industries.',
                    'summary' => 'Vetted spice allocations meeting global trade standards.'
                ],
                [
                    'num' => '04',
                    'title' => 'Crude Oil & Petroleum Products',
                    'subtitle' => 'Energy Sourcing & Refinery Allocations',
                    'desc' => 'Crude oil and refined petroleum products sourced according to agreed specifications, origin, quality parameters, and commercial requirements.',
                    'details' => 'Handling transaction verification, Proof of Product (POP), and secure banking procedures.',
                    'summary' => 'Structured energy transactions with verified allocations.'
                ],
                [
                    'num' => '05',
                    'title' => 'Cooking Oil',
                    'subtitle' => 'Edible Vegetable & Palm Oils',
                    'desc' => 'Edible cooking oils (Refined Sunflower Oil, Palm Oil, Soybean Oil) supplied to agreed quality, specification, and packaging requirements for commercial markets.',
                    'details' => 'Sourcing bulk or bottled shipments with complete health and origin certifications.',
                    'summary' => 'Edible oil supply solutions for international distributors.'
                ],
                [
                    'num' => '06',
                    'title' => 'Gold & Precious Metals',
                    'subtitle' => 'Refined Bullion & Doré Sourcing',
                    'desc' => 'Gold products sourced according to defined purity (999.9 / 995), form (bars/doré), origin, and applicable market requirements.',
                    'details' => 'Full adherence to OECD due diligence guidelines, secure transport, and refinery assay procedures.',
                    'summary' => 'Institutional gold sourcing with strict compliance verification.'
                ],
                [
                    'num' => '07',
                    'title' => 'Crypto & Selected Digital Assets',
                    'subtitle' => 'Structured OTC Digital Asset Transactions',
                    'desc' => 'Selected digital assets (Bitcoin, USDT) handled through structured transactions, subject to applicable regulations and compliance requirements.',
                    'details' => 'Facilitating regulated OTC desk settlement and institutional compliance verification.',
                    'summary' => 'Compliant digital asset transaction coordination.'
                ]
            ]
        ],

        'general-inquiry' => [
            'id' => 'general-inquiry',
            'num' => '05',
            'title' => 'General Business Inquiry',
            'heroHeadline' => 'UAE-BASED SOURCING, PROCUREMENT & <br><span style="color: var(--gold-primary);">COMMERCIAL DELIVERY SUPPORT</span>',
            'badge' => 'UAE-BASED SOURCING • PROCUREMENT • PRODUCT SUPPLY • DELIVERY SUPPORT',
            'tags' => ['UAE Sourcing', 'Procurement', 'Product Supply', 'Delivery Support'],
            'image' => 'images/verticals/supply_chain.webp',
            'shortDesc' => 'Need a specific product or business requirement from the UAE? We assist with sourcing and procurement ...',
            'overview' => 'Need a specific product or business requirement from the UAE? We assist with sourcing and procurement—from individual items and small quantities to bulk commercial and industrial requirements. From electronics and equipment to machinery, engines and industrial products, we help identify suitable UAE suppliers and coordinate delivery according to your requirements.',
            'highlightBanner' => 'Small or large — if it is commercially available in the UAE, we can help you source it.',
            'items' => [
                [
                    'num' => '01',
                    'title' => 'Commercial Sourcing & Supplier Identification',
                    'subtitle' => 'Connecting Buyers with Verified UAE Suppliers',
                    'desc' => 'We assist international businesses in identifying reliable suppliers, stockists, and authorized distributors in the UAE market.',
                    'details' => 'Verification of product specifications, pricing evaluation, and supplier background verification.',
                    'summary' => 'Direct access to UAE commercial and trading channels.'
                ],
                [
                    'num' => '02',
                    'title' => 'Industrial Machinery, Engines & Heavy Equipment',
                    'subtitle' => 'Procurement of Capital Goods & Machinery',
                    'desc' => 'Sourcing specialized machinery, diesel engines, industrial spare parts, electrical equipment, and construction hardware from UAE hubs.',
                    'details' => 'Pre-shipment inspection coordination, technical specification matching, and export documentation.',
                    'summary' => 'End-to-end procurement of industrial equipment.'
                ],
                [
                    'num' => '03',
                    'title' => 'Electronics, Commercial Commodities & General Supply',
                    'subtitle' => 'Bulk & Small Batch Commercial Supply',
                    'desc' => 'Procurement support for consumer electronics, telecommunications gear, medical supplies, and commercial merchandise.',
                    'details' => 'Consolidation of multi-vendor orders and custom packaging for export.',
                    'summary' => 'Flexible sourcing for general commercial inventory.'
                ],
                [
                    'num' => '04',
                    'title' => 'Logistics & Export Delivery Coordination',
                    'subtitle' => 'Freight Handling & Dubai Customs Clearance',
                    'desc' => 'Coordination of air freight, sea freight (FCL/LCL), warehousing, and customs clearance from Dubai ports (Jebel Ali, DWC, Port Rashid).',
                    'details' => 'Preparation of certificates of origin, bills of lading, and export compliance documents.',
                    'summary' => 'Frictionless export delivery from Dubai to global destinations.'
                ]
            ]
        ]
    ];
}
